import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {CoreModule} from './_core/core.module';
import {NgxSpinnerModule} from 'ngx-spinner';
import {SnotifyModule, SnotifyService, ToastDefaults} from 'ng-snotify';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CoreModule,
    AppRoutingModule,
    NgxSpinnerModule,
    SnotifyModule,
  ],
  providers: [{provide: 'SnotifyToastConfig', useValue: ToastDefaults}, SnotifyService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
