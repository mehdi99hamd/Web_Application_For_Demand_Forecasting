import {Injectable} from '@angular/core';
import {ToastrService} from 'ngx-toastr';
import {SnotifyPosition, SnotifyService} from 'ng-snotify';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  // constructor(private toastr: ToastrService) {
  // }
  constructor(private snotifyService: SnotifyService) {
  }

  success(title: string, message: string): void {
    this.snotifyService.success(title, message, {
      position: SnotifyPosition.leftBottom
    });
  }

  error(title: string, message: string): void {
    this.snotifyService.error(title, message, {
      position: SnotifyPosition.leftBottom
    });
  }

  // success(title: string, message: string): void {
  //   this.toastr.success(
  //     title,
  //     message,
  //     {
  //       timeOut: 3000,
  //       positionClass: 'toast-bottom-left'
  //     }
  //   );
  // }

  // error(title: string, message: string): void {
  //   this.toastr.error(
  //     title,
  //     message,
  //     {
  //       timeOut: 3000,
  //       positionClass: 'toast-bottom-left'
  //     }
  //   );
  // }
}
