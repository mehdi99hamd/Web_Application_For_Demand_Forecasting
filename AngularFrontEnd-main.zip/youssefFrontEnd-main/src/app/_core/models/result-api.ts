export interface ResultApi {
  rmse?: number;
  msd?: number;
  prevision: [{ periode: number, demande: number, prediction: number }];
}
