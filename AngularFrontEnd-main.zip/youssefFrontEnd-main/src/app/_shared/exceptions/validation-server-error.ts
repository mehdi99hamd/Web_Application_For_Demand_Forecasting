import {AppError} from './app-error';

export class ValidationServerError extends  AppError{

}
