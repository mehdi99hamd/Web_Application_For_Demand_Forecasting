import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';
import {NotFoundComponent} from './components/not-found/not-found.component';
import {NavbarComponent} from './components/navbar/navbar.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { PaginationsComponent } from './components/paginations/paginations.component';
import {ChartsModule} from 'ng2-charts';



@NgModule({
  declarations: [
    NavbarComponent,
    NotFoundComponent,
    PaginationsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    NgxPaginationModule,
    ChartsModule
  ],
  exports: [
    ReactiveFormsModule,
    FormsModule,
    NavbarComponent,
    NgxPaginationModule,
    PaginationsComponent,
    ChartsModule
  ]
})
export class SharedModule { }
