import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApplicationRoutingModule } from './application-routing.module';
import {ContainerGopComponent} from './components/container-gop/container-gop.component';
import {ImportExcelComponent} from './components/import-excel/import-excel.component';
import {ManuallyDataComponent} from './components/manually-data/manually-data.component';
import {DragDropDirective} from '../_shared/derictives/drag-drop.directive';
import {ListDataComponent} from './components/list-data/list-data.component';
import {PreferenceAlgoComponent} from './components/preference-algo/preference-algo.component';
import {SharedModule} from '../_shared/shared.module';
import { ResultListDataComponent } from './components/result-list-data/result-list-data.component';
import { ResultChartComponent } from './components/result-chart/result-chart.component';


@NgModule({
  declarations: [
    ContainerGopComponent,
    ImportExcelComponent,
    ManuallyDataComponent,
    DragDropDirective,
    ListDataComponent,
    PreferenceAlgoComponent,
    ResultListDataComponent,
    ResultChartComponent
  ],
  imports: [
    CommonModule,
    ApplicationRoutingModule,
    SharedModule
  ]
})
export class ApplicationModule { }
