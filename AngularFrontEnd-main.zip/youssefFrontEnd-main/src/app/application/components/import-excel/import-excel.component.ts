import {Component, ElementRef, OnInit, Output, EventEmitter, ViewChild} from '@angular/core';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-import-excel',
  templateUrl: './import-excel.component.html',
  styleUrls: ['./import-excel.component.css']
})
export class ImportExcelComponent implements OnInit {

  @Output() dataImportedEvent = new EventEmitter();

  fileName = 'SheetJS.xlsx';
  @ViewChild('inputFile') inputFile: ElementRef;
  isExcelFile: boolean;
  isHovering: boolean;
  isEmptyDrop = true;
  isExcelDrop = true;

  keys = [];
  data = [];

  constructor() {
  }

  ngOnInit(): void {
  }

  emitImportedData(): void {
    if (this.data.length > 0) {
      this.dataImportedEvent.emit(this.data);
    }

  }

  onFileChange(evt: any): void {
    /* wire up file reader */
    const target: DataTransfer = (evt.target) as DataTransfer;
    if (target.files.length !== 1) {
      this.inputFile.nativeElement.value = '';
      throw new Error('Cannot use multiple files');
    }
    this.isExcelFile = !!target.files[0].name.match(/(.xls|.xlsx)/);

    if (this.isExcelFile) {
      // *** this.spinnerEnabled = true;
      const reader: FileReader = new FileReader();
      reader.onload = (e: any) => {
        /* read workbook */
        const bstr: string = e.target.result;
        const wb: XLSX.WorkBook = XLSX.read(bstr, {type: 'binary'});

        /* grab first sheet */
        const wsname2: string = wb.SheetNames[0];
        const sheet = wb.Sheets[wsname2];

        /* save data */
        this.data = XLSX.utils.sheet_to_json(sheet, {defval: null});
        this.keys = Object.keys(this.data[0]);

        console.log(this.data);
        console.log(this.keys);
        this.emitImportedData();
      };
      reader.readAsBinaryString(target.files[0]);
      reader.onloadend = (e) => {
        // *** this.spinnerEnabled = false;
        // this.keys = Object.keys(data[0]);
        // this.dataSheet.next(data);
      };
    } else {
      this.inputFile.nativeElement.value = '';
      throw new Error('Excel file only');
    }
  }

  toggleHover(event: boolean): void {
    this.isHovering = event;
  }

  dropExcelOnChance(targetInput: Array<File>): void {
    // this.sheetJsExcelName = targetInput[0].name;
    if (targetInput.length !== 1) {
      throw new Error('Cannot use multiple files');
    }
    // *** this.spinnerEnabled = true;
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, {type: 'binary'});

      /* grab first sheet */
      const wsname2: string = wb.SheetNames[0];
      const sheet = wb.Sheets[wsname2];

      /* save data */
      this.data = XLSX.utils.sheet_to_json(sheet, {defval: null});
      this.keys = Object.keys(this.data[0]);

      console.log(this.data);
      console.log(this.keys);
      this.emitImportedData();
    };
    reader.readAsBinaryString(targetInput[0]);
    reader.onloadend = (e) => {
      // *** this.spinnerEnabled = false;
      // this.keys = Object.keys(data[0]);
      // this.dataSheet.next(data);
    };
    this.isEmptyDrop = false;
    this.isExcelDrop = true;
  }

  dropExcelBlock(fileList: Array<File>): void {
    if (fileList.length === 0) {
      return;
    } else {
      this.isExcelDrop = false;
      throw new Error('Excel File only');
    }
  }

}
