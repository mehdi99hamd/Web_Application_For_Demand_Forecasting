import {Component, ElementRef, OnInit} from '@angular/core';
import Stepper from 'bs-stepper';
import {NotificationService} from '../../../_core/services/notification.service';
import {PrevisionAlgosService} from '../../services/prevision-algos.service';
import {ResultApi} from '../../../_core/models/result-api';

@Component({
  selector: 'app-container-gop',
  templateUrl: './container-gop.component.html',
  styleUrls: ['./container-gop.component.css']
})
export class ContainerGopComponent implements OnInit {

  currentStep: number;
  private stepper: Stepper;
  data = [];
  preferenceAlgoStepTwo: {
    isValid: boolean,
    preference: string,
    algo: {
      algo: string,
      alpha: number,
      beta: number,
      gama: number,
      p: number,
      sp: number,
      ahead: number
    }
  };
  resultApi: ResultApi;

  constructor(private readonly elementRef: ElementRef,
              private notificationService: NotificationService,
              private previsionAlgosService: PrevisionAlgosService) {
  }

  ngOnInit(): void {
    this.initializeStepper();
  }

  initializeStepper(): void {
    const stepperEl = this.elementRef.nativeElement.querySelector('#stepper1');

    stepperEl.addEventListener('show.bs-stepper', event => {
      this.currentStep = event.detail.to;
    });

    this.stepper = new Stepper(stepperEl, {
      animation: true
    });
  }

  next(): void {
    if (this.currentStep === 0) {
      this.stepper.next();
    } else {
      if (this.preferenceAlgoStepTwo.isValid) {
        if (this.preferenceAlgoStepTwo.preference === 'one_algo') {
          let resource;
          const algo = this.preferenceAlgoStepTwo.algo.algo;
          if (algo === 'simple') {
            const alpha = this.preferenceAlgoStepTwo.algo.alpha;
            resource = {prevision: this.data, algorithme: {alpha, algo}};
          } else if (algo === 'double') {
            const alpha = this.preferenceAlgoStepTwo.algo.alpha;
            const beta = this.preferenceAlgoStepTwo.algo.alpha;
            resource = {prevision: this.data, algorithme: {alpha, beta, algo}};
          } else if (algo === 'triple') {
            resource = {prevision: this.data, algorithme: this.preferenceAlgoStepTwo.algo};
          } else if (algo === 'arima') {
            resource = {prevision: this.data, algorithme: {algo}};
          } else {
            // message  error -> no algo chosen
          }
          this.previsionAlgosService.algoApi(resource).subscribe((res: ResultApi) => {
            this.resultApi = res;
            this.stepper.next();
          });
        } else {
          // comparing
        }
      } else {
        // message invalid
      }
    }
  }

  previous(): void {
    this.stepper.previous();
  }

  onSubmit(): boolean {
    return false;
  }

  emitedData(data: any): void {
    this.data = data;
  }

  emitedPreference(data: any): void {
    this.preferenceAlgoStepTwo = data;
  }

  refreshPage(): void {
    window.location.reload();
  }
}
