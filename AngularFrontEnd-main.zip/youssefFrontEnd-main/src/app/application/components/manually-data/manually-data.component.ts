import {Component, ElementRef, EventEmitter, OnInit, Output, ViewChild} from '@angular/core';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-manually-data',
  templateUrl: './manually-data.component.html',
  styleUrls: ['./manually-data.component.css']
})
export class ManuallyDataComponent implements OnInit {

  manualDataForm: FormGroup;
  nombrePeriodForm: FormGroup;
  @Output() dataManualEvent = new EventEmitter();
  @ViewChild('closeModal') closeModal: ElementRef;

  constructor(private fb: FormBuilder) {
  }

  ngOnInit(): void {
    this.initializeNombrePeriodeForm();
  }

  initializeNombrePeriodeForm(): void {
    this.nombrePeriodForm = new FormGroup({
      nombre_periodes: new FormControl(null, [Validators.required, Validators.pattern('^[0-9]*$')])
    });
  }

  get previsionDetails(): FormArray {
    return this.manualDataForm.get('previsionDetails') as FormArray;
  }

  createform(num: number): void {
    let arr = [];
    for (let i = 0; i < num; i++) {
      arr.push(this.BuildFormDynamic(i + 1));
    }
    this.manualDataForm = this.fb.group({
      previsionDetails: this.fb.array(arr)
    });
  }

  BuildFormDynamic(index: number): FormGroup {
    return this.fb.group({
      periode: [index, [Validators.required]], /*Validators.pattern('^[0-9]*$')*/
      demande: ['', [Validators.required]] /*Validators.pattern('^[0-9]*$')*/
    });
  }

  SaveData(): void {
    // console.log(this.previsionDetails.value);
    if (this.previsionDetails.value) {
      this.dataManualEvent.emit(this.previsionDetails.value);
    }
    this.closeModal.nativeElement.click();
    // pass this data to service and api node/webapi
  }

  generer(): void {
    const num = this.nombrePeriodForm.get('nombre_periodes').value;
    this.createform(num);
    // let x: FormGroup = this.SchoolDetailsForm.controls.ClassDetails as FormGroup;
    // console.log(x.controls);
    console.log(this.previsionDetails.controls);
  }

  clearModal(): void {
    this.manualDataForm = null;
    this.nombrePeriodForm.reset();
  }
}
