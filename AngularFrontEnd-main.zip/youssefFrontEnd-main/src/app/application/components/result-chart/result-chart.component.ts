import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {ResultApi} from '../../../_core/models/result-api';
import {ChartDataSets, ChartOptions} from 'chart.js';
import {Color, Label} from 'ng2-charts';

@Component({
  selector: 'app-result-chart',
  templateUrl: './result-chart.component.html',
  styleUrls: ['./result-chart.component.css']
})
export class ResultChartComponent implements OnInit, OnChanges {

  @Input() resultApi: ResultApi;
  public lineChartData: ChartDataSets[] = [
    {data: [], label: 'Prevision', lineTension: 0, fill: false},
    {data: [], label: 'Demand', lineTension: 0, fill: false},
  ];
  public lineChartLabels: Label[] = [];
  // public lineChartOptions: (ChartOptions & { annotation: any }) = {
  //   responsive: true,
  // };
  public lineChartOptions: ChartOptions = {
    responsive: true,
    // We use these empty structures as placeholders for dynamic theming.
    scales: {
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'period'
        }
      }], yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'demand'
        }
      }]
    },
    plugins: {
      datalabels: {
        anchor: 'end',
        align: 'end',
      }
    }
  };
  public lineChartColors: Color[] = [
    {
      borderColor: '#e14eca',
      backgroundColor: 'transparent',
      pointBorderColor: 'black'
    },
  ];

  public lineChartLegend = true;
  public lineChartType = 'line';
  public lineChartPlugins = [];

  constructor() {
  }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.resultApi) {
      this.lineChartLabels = this.resultApi.prevision.map((r) => {
        return r.periode.toString();
      });
      this.lineChartData[0].data = this.resultApi.prevision.map((r) => {
        return r.prediction;
      });
      this.lineChartData[1].data = this.resultApi.prevision.map((r) => {
        return r.demande;
      });
    }
  }
}
