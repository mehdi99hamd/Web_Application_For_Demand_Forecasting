import {Component, OnInit, Output, EventEmitter} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-preference-algo',
  templateUrl: './preference-algo.component.html',
  styleUrls: ['./preference-algo.component.css']
})
export class PreferenceAlgoComponent implements OnInit {

  @Output() preferenceAlgoEvent = new EventEmitter();
  preferenceForm: FormGroup;
  oneAlgoForm: FormGroup;
  algos = [
    {name: 'Lissage exponentiel simple', value: 'simple'},
    {name: 'Lissage exponentiel double', value: 'double'},
    {name: 'Lissage exponentiel triple', value: 'triple'},
    {name: 'Arima', value: 'arima'}
  ];
  algosIsShow = false;
  variableAlgosShow = {
    alpha: false,
    beta: false,
    gama: false,
    p: false,
    sp: false,
    ahead: false
  };

  constructor() {
  }

  ngOnInit(): void {
    this.initializePreferenceForm();
    this.initializeOneAlgoForm();
  }

  initializePreferenceForm(): void {
    this.preferenceForm = new FormGroup({
      preference: new FormControl(null, [Validators.required])
    });
  }

  initializeOneAlgoForm(): void {
    this.oneAlgoForm = new FormGroup({
      algo: new FormControl(null, [Validators.required]),
      alpha: new FormControl(null, []),
      beta: new FormControl(null, []),
      gama: new FormControl(null, []),
      p: new FormControl(null, []),
      sp: new FormControl(null, []),
      ahead: new FormControl(null, [])
    });
  }

  save(): void {

  }

  onChangePreference(): void {
    const preference = this.preferenceForm.get('preference').value;
    if (preference === 'comparing') {
      this.algosIsShow = false;
    } else if (preference === 'one_algo') {
      this.algosIsShow = true;
    }
    this.emitPreference(preference);
  }

  onChangeAlgo(e): void {
    const chosedAlgo = this.oneAlgoForm.get('algo').value;
    if (chosedAlgo === 'simple') {
      this.modifyVariableAlgos(true, false, false);
    } else if (chosedAlgo === 'double') {
      this.modifyVariableAlgos(true, true, false);
    } else if (chosedAlgo === 'triple') {
      this.modifyVariableAlgos(true, true, true, true, true, true);
    } else if (chosedAlgo === 'arima') {
      this.modifyVariableAlgos();
    } else {
      this.modifyVariableAlgos(false, false, false);
    }
    this.emitPreference('one_algo');
  }

  onChangeVariableAlgos(e): void {
    this.emitPreference('one_algo');
  }

  modifyVariableAlgos(alpha: boolean = false, beta: boolean = false, gama: boolean = false, p: boolean = false, sp: boolean = false, ahead: boolean = false): void {
    this.variableAlgosShow.alpha = alpha;
    this.variableAlgosShow.beta = beta;
    this.variableAlgosShow.gama = gama;
    this.variableAlgosShow.p = p;
    this.variableAlgosShow.sp = sp;
    this.variableAlgosShow.ahead = ahead;
    this.setValidatorsToOneAlgoForm(alpha, beta, gama, p, sp, ahead);
  }

  setValidatorsToOneAlgoForm(alpha: boolean, beta: boolean, gama: boolean, p: boolean, sp: boolean, ahead: boolean): void {
    alpha === true ? this.oneAlgoForm.get('alpha').setValidators([Validators.required]) : this.oneAlgoForm.get('alpha').clearValidators();
    beta === true ? this.oneAlgoForm.get('beta').setValidators([Validators.required]) : this.oneAlgoForm.get('beta').clearValidators();
    gama === true ? this.oneAlgoForm.get('gama').setValidators([Validators.required]) : this.oneAlgoForm.get('gama').clearValidators();
    if (p && sp && ahead) {
      this.oneAlgoForm.get('p').setValidators([Validators.required]);
      this.oneAlgoForm.get('sp').setValidators([Validators.required]);
      this.oneAlgoForm.get('ahead').setValidators([Validators.required]);
    } else {
      this.oneAlgoForm.get('p').clearValidators();
      this.oneAlgoForm.get('sp').clearValidators();
      this.oneAlgoForm.get('ahead').clearValidators();
    }
    this.oneAlgoForm.get('alpha').updateValueAndValidity();
    this.oneAlgoForm.get('beta').updateValueAndValidity();
    this.oneAlgoForm.get('gama').updateValueAndValidity();
    this.oneAlgoForm.get('p').updateValueAndValidity();
    this.oneAlgoForm.get('sp').updateValueAndValidity();
    this.oneAlgoForm.get('ahead').updateValueAndValidity();
  }

  emitPreference(preference): void {
    const x = {
      isValid: preference === 'comparing' ? true : this.oneAlgoForm.valid,
      preference,
      algo: this.oneAlgoForm.value
    };
    this.preferenceAlgoEvent.emit(x);
  }
}
