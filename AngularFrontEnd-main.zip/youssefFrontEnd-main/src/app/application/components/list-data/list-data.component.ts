import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-list-data',
  templateUrl: './list-data.component.html',
  styleUrls: ['./list-data.component.css']
})
export class ListDataComponent implements OnInit {

  @Input() data = [];
  config = {
    id: 'idPagination1',
    itemsPerPage: 4,
    currentPage: 1,
    totalItems: this.data.length
  };
  constructor() { }

  ngOnInit(): void {
  }

}
