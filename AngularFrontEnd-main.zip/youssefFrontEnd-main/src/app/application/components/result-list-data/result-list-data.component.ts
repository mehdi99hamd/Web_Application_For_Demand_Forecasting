import {Component, Input, OnInit} from '@angular/core';
import {ResultApi} from '../../../_core/models/result-api';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-result-list-data',
  templateUrl: './result-list-data.component.html',
  styleUrls: ['./result-list-data.component.css']
})
export class ResultListDataComponent implements OnInit {

  @Input() resultApi: ResultApi;
  config = {
    id: 'idPagination2',
    itemsPerPage: 4,
    currentPage: 1
  };
  /*name of the excel-file which will be downloaded. */
  fileName = 'Prediction.xlsx';

  constructor() {
  }

  ngOnInit(): void {
  }


  exportexcel(): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.resultApi.prevision);
    const workbook: XLSX.WorkBook = {Sheets: {data: worksheet}, SheetNames: ['data']};
    XLSX.writeFile(workbook, this.fileName);
  }
}
