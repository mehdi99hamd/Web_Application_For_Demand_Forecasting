import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ContainerGopComponent} from './components/container-gop/container-gop.component';

const routes: Routes = [
  {path: '', component: ContainerGopComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ApplicationRoutingModule { }
